# Portfolio V3 - Selected digital projects
Static portfolio based on the original marketing portfolio content.

For a preview, add projects-preview.html at the root of a repository with matching V2 assets and PDFs. For production, replace index.html. No custom domain changes are required.

For a standalone deployment, extract this archive and publish its contents. No CNAME is included.

Premium Hub and Jiran Deal are independent, browser-only product concept demonstrations. Plans, prices, offers and orders are illustrative; no payments, subscription activation, merchant services or external account access occur. The growth calculator is an illustrative scenario. Third-party video playback and FormSubmit require a live network connection. Google Fonts are externally hosted.
